
import './App.css';
import StudentDetails from './student-components/StudentDetails';

function App() {
  return (
    <div className="App">
     < StudentDetails />
    </div>
  );
}

export default App;
